create function __geo_get_another_fields_count_for_cadastral_for_field(cadastralid_ bigint, fieldid_ bigint) returns bigint
    language sql
as
$$   
select count(distinct f.id)
from "Field" f inner join 
		("FieldDetachedRegion" fdr inner join "DetachedRegion" dr on (fdr.detachedregionid = dr.id AND dr.cadastralid = cadastralid_))
			 on f.id = fdr.fieldid
where f.id <> fieldid_;

$$;

alter function __geo_get_another_fields_count_for_cadastral_for_field(bigint, bigint) owner to postgres;

