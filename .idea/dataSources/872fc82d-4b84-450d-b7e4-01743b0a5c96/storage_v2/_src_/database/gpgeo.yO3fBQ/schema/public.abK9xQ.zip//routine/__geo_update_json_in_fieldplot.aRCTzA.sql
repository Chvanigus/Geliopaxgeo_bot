create function __geo_update_json_in_fieldplot(id_ bigint, plotgeometry_ text) returns void
    language plpgsql
as
$$ 
BEGIN
	UPDATE public."FieldPlot" SET plotgeometry = ST_GeomFromGeoJSON(plotgeometry_) WHERE id = id_;
END;
$$;

alter function __geo_update_json_in_fieldplot(bigint, text) owner to postgres;

