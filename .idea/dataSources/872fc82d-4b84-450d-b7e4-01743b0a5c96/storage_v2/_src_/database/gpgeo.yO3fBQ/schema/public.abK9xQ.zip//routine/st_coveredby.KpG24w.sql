create function st_coveredby(geography, geography) returns boolean
    immutable
    language sql
as
$$SELECT $1 && $2 AND _ST_Covers($2, $1)$$;

comment on function st_coveredby(geography, geography) is 'args: geogA, geogB - Returns 1 (TRUE) if no point in Geometry/Geography A is outside Geometry/Geography B';

alter function st_coveredby(geography, geography) owner to postgres;

