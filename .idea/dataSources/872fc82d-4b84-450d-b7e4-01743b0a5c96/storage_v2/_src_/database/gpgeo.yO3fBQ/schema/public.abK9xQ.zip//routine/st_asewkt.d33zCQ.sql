create function st_asewkt(text) returns text
    immutable
    strict
    language sql
as
$$ SELECT ST_AsEWKT($1::geometry);  $$;

alter function st_asewkt(text) owner to postgres;

