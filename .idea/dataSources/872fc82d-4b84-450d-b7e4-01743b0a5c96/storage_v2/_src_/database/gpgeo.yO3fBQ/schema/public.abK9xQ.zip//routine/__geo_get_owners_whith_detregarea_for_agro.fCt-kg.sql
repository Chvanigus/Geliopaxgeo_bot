create function __geo_get_owners_whith_detregarea_for_agro(agroid_ integer)
    returns TABLE(id integer, name character varying, color text, area numeric)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY  
	SELECT 	o1.id AS id,
			o1.name AS name,
			'#'||o1.color AS color,
			o2.area	AS area	 
	FROM		
		"Owner" o1 
				
		inner join 				
				
		(SELECT 	o.id AS id,						
					round(sum(dr.area)::numeric , 2)::numeric AS area							
						
		FROM "Owner" o
			INNER JOIN (
			"DetachedRegionOwner" dro
				INNER JOIN (
				"DetachedRegion" dr
					INNER JOIN (
					"FieldDetachedRegion" fdr
						INNER JOIN "Field" f ON ( fdr.fieldid = f.id AND f.agroid = agroid_ )
					) ON fdr.detachedregionid = dr.id
					INNER JOIN "Cadastral" c on c.id = dr.cadastralid  
				) ON dr.id = dro.detachedregionid
			) ON o.id = dro.ownerid	
		group by o.id) as o2
				
		on o1.id = o2.id
		order by o2.area DESC;
		
END;
$$;

alter function __geo_get_owners_whith_detregarea_for_agro(integer) owner to postgres;

