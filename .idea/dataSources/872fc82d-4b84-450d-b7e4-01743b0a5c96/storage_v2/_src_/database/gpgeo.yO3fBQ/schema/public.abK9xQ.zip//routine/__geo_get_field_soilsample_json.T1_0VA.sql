create function __geo_get_field_soilsample_json(fieldid_ integer) returns json
    language plpgsql
as
$$ 
  
BEGIN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft1)) As features
FROM (SELECT    'Feature' As type
				, ST_AsGeoJSON(ft.geometry)::json As geometry
				,row_to_json(row(ft.samplecode, round (cast (ST_Area(ST_Transform(ft.geometry, 32638)) / 10000 as numeric), 2), ST_X (ST_Centroid(ft.geometry)), ST_Y (ST_Centroid(ft.geometry)), ft.samples)::"soilSampleProp") as properties 	
from
	(select	ffs.samplecode
			,array_to_json(array_agg(ffs)) As samples
		
			,(CASE WHEN sss.samplegeometry is not null 	THEN sss.samplegeometry 
														ELSE ff.fieldgeometry
			 END) as geometry
	from		
		(select   ss.samplecode as "samplecode"
				, ss.year as "Year"
				, ss.nitrogen as "N"
				, ss.phosphorus as "P"
				, ss.potassium as "K"
				, ss.humus as "G"		
		 from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.id = fieldid_)
		) as ffs

	left outer join "SoilSampleShape" sss on (ffs.samplecode = sss.samplecode)
	inner join 
		(select  f.id
				,fs.year
				,fs.fieldgeometry
		from "Field" f inner join "FieldShape" As fs on (f.id = fs.fieldid AND f.id = fieldid_)
		) as ff on ff.year = ffs."Year"

	group by ffs.samplecode, geometry) As ft ) As ft1
) As ftc;	

END
$$;

alter function __geo_get_field_soilsample_json(integer) owner to postgres;

