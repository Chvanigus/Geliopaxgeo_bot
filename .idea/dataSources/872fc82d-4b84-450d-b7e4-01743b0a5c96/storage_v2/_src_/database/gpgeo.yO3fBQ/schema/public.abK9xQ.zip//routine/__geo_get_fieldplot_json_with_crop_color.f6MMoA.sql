create function __geo_get_fieldplot_json_with_crop_color(fieldcropid_ bigint) returns json
    language plpgsql
as
$$   
BEGIN
    return row_to_json(fpc) 
	FROM (
		SELECT 	 'Feature' As type
				,row_to_json(c) as properties
				,ST_AsGeoJSON(fp.plotgeometry)::json As geometry
				
	    FROM "FieldCrop" fc inner join "FieldPlot" fp on (fp.id = fc.fieldplotid AND fc.id = fieldcropid_)
							inner join (Select 	 id as "cr"
												,'#'||color as "color" 
										from "Crop") as c 
							on (c.cr = fc.cropid AND fc.id = fieldcropid_)
	) As fpc;
END;
$$;

alter function __geo_get_fieldplot_json_with_crop_color(bigint) owner to postgres;

