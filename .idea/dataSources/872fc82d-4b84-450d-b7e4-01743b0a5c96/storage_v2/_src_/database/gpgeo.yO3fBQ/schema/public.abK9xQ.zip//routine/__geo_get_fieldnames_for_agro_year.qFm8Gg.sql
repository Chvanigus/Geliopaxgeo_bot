create function __geo_get_fieldnames_for_agro_year(agroid_ integer, year_ integer)
    returns TABLE(id bigint, name character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	select  distinct f.id, 
			f.name	
	from "Field" f inner join "FieldShape" fs on (f.id = fs.fieldid AND f.agroid = agroid_ AND fs.year = year_)
	order by f.name;	
END;
$$;

alter function __geo_get_fieldnames_for_agro_year(integer, integer) owner to postgres;

