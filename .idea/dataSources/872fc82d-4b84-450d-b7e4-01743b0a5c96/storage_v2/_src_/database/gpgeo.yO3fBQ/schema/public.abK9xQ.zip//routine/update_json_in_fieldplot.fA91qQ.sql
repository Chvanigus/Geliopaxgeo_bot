create function update_json_in_fieldplot(id_ integer, plotgeometry_ text) returns void
    language plpgsql
as
$$ 
BEGIN
UPDATE public.fieldplot SET plotgeometry = ST_GeomFromGeoJSON(plotgeometry_) WHERE id = id_;
END;
$$;

alter function update_json_in_fieldplot(integer, text) owner to geoadmin;

