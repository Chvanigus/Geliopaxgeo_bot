create function st_pixelofvalue(rast raster, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer) returns SETOF record
    immutable
    strict
    language sql
as
$$
SELECT x, y FROM st_pixelofvalue($1, 1, ARRAY[$2], $3)
$$;

comment on function st_pixelofvalue(raster, double precision, boolean, out integer, out integer) is 'args: rast, search, exclude_nodata_value=true - Get the columnx, rowy coordinates of the pixel whose value equals the search value.';

alter function st_pixelofvalue(raster, double precision, boolean, out integer, out integer) owner to postgres;

