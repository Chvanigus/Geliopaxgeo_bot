create function __geo_rep_top_predecessor_int(year_ bigint, fieldid_ bigint)
    returns TABLE(cn character varying)
    language plpgsql
as
$$
BEGIN
   RETURN QUERY
   
	--select   fc.id as "FieldCrop_id"	
	--		,fc.accountcroparea as "FieldCrop_accountcroparea"
	--		,fc.yieldfact as "FieldCrop_yieldfact"
	--		,fc.cropid as "FieldCrop_cropid"
			
	--from 	"FieldCrop" fc 
	
	--where 	fc.fieldid = fieldid_ AND fc.yieldyear = (year_ - 1);

	SELECT  

"Crop".Name as cn
--,"FieldCrop".accountcroparea as acc_area
--,"FieldCrop".fieldid as field_id
--,"FieldCrop".yieldyear as yieldyear


FROM

public."FieldCrop",
public."Crop"

WHERE

"FieldCrop".fieldid = fieldid_ AND
"FieldCrop".yieldyear = (year_ - 1) AND
"FieldCrop".cropid = "Crop".id

ORDER BY "FieldCrop".accountcroparea DESC

LIMIT 1;



	
END;
$$;

alter function __geo_rep_top_predecessor_int(bigint, bigint) owner to geoadmin;

