create function __geo_get_visitorslist()
    returns TABLE(id bigint, login character varying, firstname character varying, secondname character varying, surname character varying, role character varying, authdate text, userip character varying, agros integer[])
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
select 

u.id,
u.login,
u.firstname,
u.secondname,
u.surname,
r.name as "role",
to_char(a.authdate, 'DD.MM.YYYY HH24:MI:SS') as "authdate",
a.userip,
au.agros

from
"Authorization" a inner join ("User" u inner join "Role" r on u.role = r.id
								 left outer join 
									(select  userid
											,array_agg(agroid) as agros
									 from "AgroUser"
									 group by userid 
									)au on u.id = au.userid
						) on a.userid = u.id
order by a.authdate DESC;
END;
$$;

alter function __geo_get_visitorslist() owner to postgres;

