create function __geo_get_cadastrals_for_field_for_owner(fieldid_ bigint, ownerid_ integer)
    returns TABLE("Cadastral_id" bigint, "Cadastral_number" character varying, "Cadastral_officialarea" real)
    language plpgsql
as
$$
BEGIN
	if ownerid_ = -1 then
		RETURN QUERY
		SELECT  c.id as "Cadastral_id",
				c.number as "Cadastral_number",
				c.officialarea as "Cadastral_officialarea"		
		From "DetachedRegion" dr inner join "FieldDetachedRegion" fdr on (dr.id = fdr.detachedregionid And fdr.fieldid = fieldid_)
						   inner join "Cadastral" c on c.id = dr.cadastralid					   
		ORDER BY c.number;
	else
		RETURN QUERY
		SELECT  c.id as "Cadastral_id",
				c.number as "Cadastral_number",
				c.officialarea as "Cadastral_officialarea"		
		From "DetachedRegion" dr inner join "FieldDetachedRegion" fdr on (dr.id = fdr.detachedregionid And fdr.fieldid = fieldid_)
						   inner join "Cadastral" c on c.id = dr.cadastralid					   
						   left outer join "DetachedRegionOwner" dro on (dr.id = dro.detachedregionid And dro.ownerid = ownerid_) 
		where dro.detachedregionid is null					   
		ORDER BY c.number;
	end if;
END;
$$;

alter function __geo_get_cadastrals_for_field_for_owner(bigint, integer) owner to postgres;

