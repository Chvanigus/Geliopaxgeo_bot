create function __geo_get_fieldweather_years_list(fieldid_ integer)
    returns TABLE(year integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
    select 	distinct EXTRACT(YEAR FROM fwd.date)::INTEGER as year		
	from 	"FieldWeatherData" fwd inner join "FieldWeatherDataField" fwdf on (fwd.id = fwdf.fieldweatherdataid and fwdf.fieldid = fieldid_)	
	order by year desc;
END;
$$;

alter function __geo_get_fieldweather_years_list(integer) owner to postgres;

