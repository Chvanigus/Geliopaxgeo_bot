create function geo_get_fieldplot_area_perimetr_arrayxy(fieldplotid_ integer)
    returns TABLE(lon double precision, lat double precision, area_ha numeric, perimeter_km numeric)
    language sql
as
$$   
SELECT  
      ST_X ((dp).geom) As x,  
	  ST_Y ((dp).geom) As y,
	  round (cast (ST_Area(plotgeom) / 10000 as numeric), 2) As area_ha,
	  round (cast (ST_Perimeter(plotgeom) / 1000 as numeric), 2) As perimeter_km
FROM 
	(SELECT 
			ST_DumpPoints(plotgeometry) AS dp,
			ST_Transform(ST_SetSRID(plotgeometry, 4326), 32638) AS plotgeom
	from public.fieldplot 
	where id = fieldplotid_)	
As foo;

$$;

alter function geo_get_fieldplot_area_perimetr_arrayxy(integer) owner to geoadmin;

