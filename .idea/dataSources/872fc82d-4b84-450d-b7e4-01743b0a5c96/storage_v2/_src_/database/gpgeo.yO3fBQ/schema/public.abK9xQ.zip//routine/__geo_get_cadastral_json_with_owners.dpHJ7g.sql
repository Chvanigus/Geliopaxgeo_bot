create function __geo_get_cadastral_json_with_owners(agroid_ integer, year_ integer) returns json
    language plpgsql
as
$$   
BEGIN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fs1.fieldgeometry)::json As geometry
		, row_to_json(pr) As properties

from "FieldShape" fs1 

inner join 

(select   
		  ffs.f as "f"
		, ffs."FieldNum" as "FieldNum"
		, ffs."AreaCalc" As "AreaCalc"
		, ffs."CentrX" As "CentrX"
		, ffs."CentrY" As "CentrY"
		, array_agg(fc) as "Cadastral"
from
	(select   f.id as "f"
			, f.name as "FieldNum"					
			, round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "AreaCalc"
			, ST_X (ST_Centroid(fs.fieldgeometry)) As "CentrX"
			, ST_Y (ST_Centroid(fs.fieldgeometry)) As "CentrY"
	from "Field" f inner join "FieldShape" fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)
	) as ffs

	left outer join 
	
	(select	 f.id as "f"
			, c.number as "CadastralNumberFull"
			, substring(c.number from '\:[0-9]*$') as "CadastralNumber"	
			, dr.area as "DetRegArea"
			, array_agg(own) as "Owner"
		
	from 	"Field" f 
			inner join  ("FieldDetachedRegion" fdr 
						inner join  ("DetachedRegion" dr 
									inner join "Cadastral" c on c.id = dr.cadastralid
									left outer join 
									(select  dro.detachedregionid as "dr"
											, o.name as "Name"
											, '#'||o.color as "Color"
											, cot.shortname as "OwnerType"
									from    "DetachedRegionOwner" dro 
											inner join ("Owner" o inner join "CadastralOwnerType" cot on o.cadastralownertypeid = cot.id)
										    on dro.ownerid = o.id) as own
									on dr.id = own.dr) 
						on dr.id = fdr.detachedregionid) 
			on (f.id = fdr.fieldid AND f.agroid = agroid_)
	group by f.id, c.number, "CadastralNumber", dr.id, dr.area
	) as  fc

	on  ffs.f = fc.f
group by ffs.f, ffs."FieldNum", ffs."AreaCalc", ffs."CentrX", ffs."CentrY"
) as pr

on (fs1.fieldid = pr.f AND fs1.year = year_)) As ft) As ftc;

END
$$;

alter function __geo_get_cadastral_json_with_owners(integer, integer) owner to postgres;

