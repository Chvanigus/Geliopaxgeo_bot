create function __geo_check_user_weathergroup_access(userid_ bigint, weathergroupid_ integer) returns integer
    language sql
as
$$   
	select wga.weathergroupid
	from "User" u inner join 
		("AgroUser" au inner join 
			("Agro" a inner join 
				"WeatherGroupAgro" wga on (a.id = wga.agroid AND wga.weathergroupid = weathergroupid_))
			on a.id = au.agroid)
		on u.id = au.userid;
$$;

alter function __geo_check_user_weathergroup_access(bigint, integer) owner to postgres;

