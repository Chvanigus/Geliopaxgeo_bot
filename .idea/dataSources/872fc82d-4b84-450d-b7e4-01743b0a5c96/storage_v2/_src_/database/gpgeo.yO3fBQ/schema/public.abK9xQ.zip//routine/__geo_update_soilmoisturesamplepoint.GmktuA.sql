create function __geo_update_soilmoisturesamplepoint(id_ bigint, soilmoisturesampleid_ bigint, lat_ double precision, lon_ double precision) returns void
    language plpgsql
as
$$ 
BEGIN
	UPDATE public."SoilMoistureSamplePoint" 
	SET soilmoisturesampleid = soilmoisturesampleid_,
		samplepoint = ST_SetSRID(ST_MakePoint(lon_, lat_), 4326)
	WHERE id = id_;
END;
$$;

alter function __geo_update_soilmoisturesamplepoint(bigint, bigint, double precision, double precision) owner to geoadmin;

