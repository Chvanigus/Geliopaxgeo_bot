create function st_valuepercent(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, searchvalues double precision[] DEFAULT NULL::double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
    stable
    language sql
as
$$
SELECT value, percent FROM _st_valuecount($1, $2, $3, $4, $5, $6)
$$;

alter function st_valuepercent(text, text, integer, boolean, double precision[], double precision, out double precision, out double precision) owner to postgres;

