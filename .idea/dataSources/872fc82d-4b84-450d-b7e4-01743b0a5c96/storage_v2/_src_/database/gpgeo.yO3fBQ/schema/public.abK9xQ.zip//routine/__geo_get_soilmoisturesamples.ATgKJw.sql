create function __geo_get_soilmoisturesamples(fieldid_ bigint)
    returns TABLE(year integer, id bigint, date date, fieldid bigint, fieldcropid bigint, layer010 integer, layer1020 integer, layer2030 integer, layer3040 integer, layer4050 integer, layer5060 integer, layer6070 integer, layer7080 integer, layer8090 integer, layer90100 integer, smsp_id bigint, lat double precision, lon double precision, latlon_dms text)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
select   EXTRACT(YEAR FROM sms.date)::INTEGER as "year"
		,sms.id as "SoilMoistureSample_id"
	    ,sms.date as "SoilMoistureSample_date"
		,sms.fieldid as "SoilMoistureSample_fieldid"
		,sms.fieldcropid as "SoilMoistureSample_fieldcropid"
		,sms.layer010 as "SoilMoistureSample_layer010"
		,sms.layer1020 as "SoilMoistureSample_layer1020"
		,sms.layer2030 as "SoilMoistureSample_layer2030"
		,sms.layer3040 as "SoilMoistureSample_layer3040"
		,sms.layer4050 as "SoilMoistureSample_layer4050"
		,sms.layer5060 as "SoilMoistureSample_layer5060"
		,sms.layer6070 as "SoilMoistureSample_layer6070"
		,sms.layer7080 as "SoilMoistureSample_layer7080"
		,sms.layer8090 as "SoilMoistureSample_layer8090"
		,sms.layer90100 as "SoilMoistureSample_layer90100"
		,smsp.id as "SoilMoistureSamplePoint_id"
		,st_y(smsp.samplepoint) as "SoilMoistureSamplePoint_lat"
		,st_x(smsp.samplepoint) as "SoilMoistureSamplePoint_lon"
		,ST_AsLatLonText(smsp.samplepoint, 'D M S') as "SoilMoistureSamplePoint_latlon_dms"		

from "SoilMoistureSample" sms 
		inner join  "Field" f  on (f.id = sms.fieldid and f.id = fieldid_)		
		left outer join "FieldCrop" fc  on (fc.id = sms.fieldcropid and sms.fieldid = fieldid_)		
		left outer join "SoilMoistureSamplePoint" smsp on sms.id = smsp.soilmoisturesampleid
order by EXTRACT(YEAR FROM sms.date)::INTEGER DESC, sms.date DESC;
END;
$$;

alter function __geo_get_soilmoisturesamples(bigint) owner to postgres;

