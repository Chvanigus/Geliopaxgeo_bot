create function __geo_get_year_weather_for_weathergroup(weathergroupid_ integer, year_ integer)
    returns TABLE("WeatherData_month" integer, "WeatherData_temperature_avg" double precision, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherData_rain_sum" real)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  t1._month as "WeatherData_month",
			t1._temperature_avg as "WeatherData_temperature_avg",
			t1._temperature_min "WeatherData_temperature_min",
			t1._temperature_max as "WeatherData_temperature_max",		
			t1._rain_sum as "WeatherData_rain_sum"
	from
		(select EXTRACT(MONTH FROM wd.datetime)::INTEGER as "_month",
				avg(wd.temperature) as "_temperature_avg",
				min(wd.temperature) as "_temperature_min",
				max(wd.temperature) as "_temperature_max",
				sum(wd.rain) as "_rain_sum"
		from "WeatherData" as wd inner join "WeatherStation" ws on (ws.id = wd.weatherstationid and EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_ and ws.weathergroupid = weathergroupid_)		
		group by "_month") as t1	
	order by t1._month DESC;
END;
$$;

alter function __geo_get_year_weather_for_weathergroup(integer, integer) owner to geoadmin;

