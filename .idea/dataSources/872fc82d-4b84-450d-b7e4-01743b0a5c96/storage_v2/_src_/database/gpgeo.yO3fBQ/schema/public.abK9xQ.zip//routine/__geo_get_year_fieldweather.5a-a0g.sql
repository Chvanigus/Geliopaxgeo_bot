create function __geo_get_year_fieldweather(fieldid_ bigint, year_ integer)
    returns TABLE("WeatherData_month" integer, "WeatherData_month_full" text, "WeatherData_temperature_avg" numeric, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherData_rain_sum" numeric)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select 		EXTRACT(MONTH FROM fwd.date)::INTEGER as "WeatherData_month",
				to_char(fwd.date, 'TMMonth') as "WeatherData_month_full",
				round(avg(fwd.temperaturemean)::numeric , 2)::numeric  as "WeatherData_temperature_avg",
				min(fwd.temperaturemin) as "WeatherData_temperature_min",
				max(fwd.temperaturemax) as "WeatherData_temperature_max",
				round(sum(fwd.dailyrain)::numeric , 2)::numeric  as "WeatherData_rain_sum"
	from "FieldWeatherData" fwd inner join "FieldWeatherDataField" fwdf
	on (fwd.id = fwdf.fieldweatherdataid and fwdf.fieldid = fieldid_ AND EXTRACT(YEAR FROM fwd.date)::INTEGER = year_)
	group by "WeatherData_month", "WeatherData_month_full"	
	order by "WeatherData_month" DESC;
END;
$$;

alter function __geo_get_year_fieldweather(bigint, integer) owner to postgres;

