create function __geo_predecessor(year_ integer, fieldid_ integer)
    returns TABLE("FieldCrop_id" bigint, "FieldCrop_accountcroparea" real, "FieldCrop_yieldfact" real, "FieldCrop_cropid" integer)
    language plpgsql
as
$$
BEGIN
   RETURN QUERY
   
	select   fc.id as "FieldCrop_id"	
			,fc.accountcroparea as "FieldCrop_accountcroparea"
			,fc.yieldfact as "FieldCrop_yieldfact"
			,fc.cropid as "FieldCrop_cropid"
			
	from 	"FieldCrop" fc 
	
	where 	fc.fieldid = fieldid_ AND fc.yieldyear = (year_ - 1);
	
END;
$$;

alter function __geo_predecessor(integer, integer) owner to postgres;

