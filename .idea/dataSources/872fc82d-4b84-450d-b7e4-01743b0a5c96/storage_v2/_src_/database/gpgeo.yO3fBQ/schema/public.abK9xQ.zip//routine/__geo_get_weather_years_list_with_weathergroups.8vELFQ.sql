create function __geo_get_weather_years_list_with_weathergroups(agroid_ integer)
    returns TABLE(year integer, weathergroup character varying, weathergroupid integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
select 	 EXTRACT(YEAR FROM wd.datetime)::INTEGER as year
		,wg.name as weathergroup
		,wg.id as weathergroupid
from 	"WeatherData" wd 
		inner join 	("WeatherStation" ws
						inner join ("WeatherGroup" wg 
									inner join "WeatherGroupAgro" wga 
									on (wg.id = wga.weathergroupid and wga.agroid = agroid_)) 
						on ws.weathergroupid = wg.id)
		on ws.id = wd.weatherstationid
group by year, wg.name, wg.id
order by year desc;
END;
$$;

alter function __geo_get_weather_years_list_with_weathergroups(integer) owner to geoadmin;

