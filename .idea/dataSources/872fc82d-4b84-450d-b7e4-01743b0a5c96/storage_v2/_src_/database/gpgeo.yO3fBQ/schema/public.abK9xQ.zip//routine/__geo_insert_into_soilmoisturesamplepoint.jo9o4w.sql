create function __geo_insert_into_soilmoisturesamplepoint(soilmoisturesampleid_ bigint, lat_ double precision, lon_ double precision) returns bigint
    language plpgsql
as
$$ 
	DECLARE
		t_id bigint;
	BEGIN
		INSERT INTO public."SoilMoistureSamplePoint"(soilmoisturesampleid, samplepoint) VALUES (soilmoisturesampleid_, ST_SetSRID(ST_MakePoint(lon_, lat_), 4326))
		RETURNING id into t_id;
		RETURN t_id;
	END;
$$;

alter function __geo_insert_into_soilmoisturesamplepoint(bigint, double precision, double precision) owner to geoadmin;

