create function __geo_get_month_fieldweather(fieldid_ bigint, year_ integer, month_ integer)
    returns TABLE("WeatherData_date" text, "WeatherData_temperature_avg" real, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherData_rain_max" real)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select 	to_char(fwd.date, 'DD.MM.YYYY') as "WeatherData_date",
			fwd.temperaturemean as "WeatherData_temperature_avg",
			fwd.temperaturemin as "WeatherData_temperature_min",
			fwd.temperaturemax as "WeatherData_temperature_max",
			fwd.dailyrain as "WeatherData_rain_max"
	from "FieldWeatherData" fwd inner join "FieldWeatherDataField" fwdf
	on (fwd.id = fwdf.fieldweatherdataid and fwdf.fieldid = fieldid_ AND EXTRACT(YEAR FROM fwd.date)::INTEGER = year_ AND EXTRACT(MONTH FROM fwd.date)::INTEGER = month_)	
	order by "WeatherData_date" DESC;
END;
$$;

alter function __geo_get_month_fieldweather(bigint, integer, integer) owner to postgres;

