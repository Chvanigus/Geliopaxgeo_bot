create function __geo_get_lastmonth_for_year_for_agro(agroid_ integer, year_ integer) returns integer
    language plpgsql
as
$$
BEGIN
	RETURN 	MAX(EXTRACT(MONTH FROM wd.datetime)::INTEGER) as last_month		
	from 	"WeatherData" wd 
				inner join ("WeatherStation" ws 
								inner join ("WeatherGroup" wg 
												inner join "WeatherGroupAgro" wga on wg.id = wga.weathergroupid AND wga.agroid = agroid_)
								on ws.weathergroupid = wg.id)
				on (wd.weatherstationid = ws.id AND EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_);	
END;
$$;

alter function __geo_get_lastmonth_for_year_for_agro(integer, integer) owner to geoadmin;

