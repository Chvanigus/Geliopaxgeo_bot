create function __geo_get_permited_agros_for_user(userid_ bigint)
    returns TABLE(agroid integer)
    language plpgsql
as
$$
BEGIN 
	RETURN QUERY 
	select au.agroid as agroid
	from "AgroUser" au inner join "User" u on (au.userid = u.id AND u.id = userid_);
END;
$$;

alter function __geo_get_permited_agros_for_user(bigint) owner to postgres;

