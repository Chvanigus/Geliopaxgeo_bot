create function __geo_get_owners_whith_detached_regions_cadastrals(fieldid_ bigint)
    returns TABLE("Owner_id" integer, "Owner_name" character varying, "Owner_contactinformation" text, "Owner_cadastralownertypeid" integer, "Owner_color" character varying, "DetachedRegionOwner_id" bigint, "DetachedRegionOwner_detachedregionid" bigint, "DetachedRegionOwner_ownerid" integer, "DetachedRegionOwner_rentalenddate" date, "DetachedRegionOwner_rentalstartdate" date, "DetachedRegionOwner_landsurveydate" date, "DetachedRegionOwner_landsurveynumber" character varying, "DetachedRegionOwner_additional" text, "DetachedRegionOwner_rentalcontractnumber" character varying, "Cadastral_id" bigint, "Cadastral_number" character varying, "Cadastral_officialarea" real, "Cadastral_additional" text, "DetachedRegion_id" bigint, "DetachedRegion_number" character varying, "DetachedRegion_area" real, "DetachedRegion_additional" text, "DetachedRegion_cadastralid" bigint)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  o.id as "Owner_id",
			o.name as "Owner_name", 
			o.contactinformation as "Owner_contactinformation", 
			o.cadastralownertypeid as "Owner_cadastralownertypeid", 
			o.color as "Owner_color", 
				
			dro.id as "DetachedRegionOwner_id",
			dro.detachedregionid as "DetachedRegionOwner_detachedregionid",
			dro.ownerid as "DetachedRegionOwner_ownerid",
			dro.rentalenddate as "DetachedRegionOwner_rentalenddate",
			dro.rentalstartdate as "DetachedRegionOwner_rentalstartdate",
			dro.landsurveydate as "DetachedRegionOwner_landsurveydate",
			dro.landsurveynumber as "DetachedRegionOwner_landsurveynumber",
			dro.additional as "DetachedRegionOwner_additional",
			dro.rentalcontractnumber as "DetachedRegionOwner_rentalcontractnumber",
		
			c.id as "Cadastral_id",
			c.number as "Cadastral_number",
			c.officialarea as "Cadastral_officialarea",
			c.additional as "Cadastral_additional",
		
			dr.id as "DetachedRegion_id",
			dr.number as "DetachedRegion_number",
			dr.area as "DetachedRegion_area",
			dr.additional as "DetachedRegion_additional",
			dr.cadastralid as "DetachedRegion_cadastralid"			
	from "Owner" o inner join ("DetachedRegionOwner" dro inner join ("DetachedRegion" dr inner join "FieldDetachedRegion" fdr on (fdr.detachedregionid = dr.id AND fdr.fieldid = fieldid_)
																						 left outer join "Cadastral" c on dr.cadastralid = c.id) on dr.id = dro.detachedregionid) on o.id = dro.ownerid 		
	order by o.id, c.id, dr.id;
END;
$$;

alter function __geo_get_owners_whith_detached_regions_cadastrals(bigint) owner to postgres;

