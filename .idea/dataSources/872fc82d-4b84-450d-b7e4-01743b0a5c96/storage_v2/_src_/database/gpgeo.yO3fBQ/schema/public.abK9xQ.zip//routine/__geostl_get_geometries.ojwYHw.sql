create function __geostl_get_geometries(year_ integer, proj_ integer, fieldid_ integer, agroid_ integer, polygon_ text)
    returns TABLE(feature text, fieldid integer)
    language plpgsql
as
$$
BEGIN

	IF fieldid_ IS NOT NULL THEN
		RETURN QUERY
		SELECT  ST_AsText(ST_Transform(fs.fieldgeometry, proj_))
			   ,fs.fieldid
		FROM "FieldShape" fs 
		WHERE fs.fieldid = fieldid_
		  AND fs.year = year_								
		  AND ST_Intersects( ST_SetSRID(ST_GeomFromText(polygon_), proj_), ST_Transform(fs.fieldgeometry, proj_) );
	  
	ELSIF agroid_ IS NULL THEN
		RETURN QUERY
		SELECT  ST_AsText(ST_Transform(fs.fieldgeometry, proj_))
		       ,f.id
		FROM "FieldShape" fs inner join "Field" f  ON ( f.id = fs.fieldid 
								AND fs.year = year_								
								AND ST_Intersects(ST_SetSRID(ST_GeomFromText(polygon_), proj_), ST_Transform(fs.fieldgeometry, proj_)) );
								
	ELSE
		RETURN QUERY
		SELECT  ST_AsText(ST_Transform(fs.fieldgeometry, proj_))
		       ,f.id
		FROM "FieldShape" fs inner join "Field" f  ON ( f.id = fs.fieldid 
								AND fs.year = year_ 
								AND f.agroid = agroid_ 
								AND ST_Intersects(ST_SetSRID(ST_GeomFromText(polygon_), proj_), ST_Transform(fs.fieldgeometry, proj_)) );
	END IF;
END;
$$;

alter function __geostl_get_geometries(integer, integer, integer, integer, text) owner to geoadmin;

