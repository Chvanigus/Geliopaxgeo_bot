create function __geo_get_fieldshape_json(agroid_ integer, year_ integer) returns json
    language plpgsql
as
$$   
BEGIN
   return 
			(CASE WHEN features is not null THEN row_to_json(ftc) 
											ELSE null
			END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fs1.fieldgeometry)::json As geometry
		, row_to_json(ffs) As properties		
		
from "FieldShape" fs1 inner join 

(select   f.id as "f"
		, f.name as "FieldNum"
		, f.agroid as "Agro"
	    , ffg.fieldgroupid as "FieldGroup"
		, round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "AreaCalc"
		, ST_X (ST_Centroid(fs.fieldgeometry)) As "CentrX"
		, ST_Y (ST_Centroid(fs.fieldgeometry)) As "CentrY"
from "Field" f inner join "FieldShape" fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)
			    left outer join "FieldFieldGroup" as ffg on(f.id = ffg.fieldid AND ffg.year = year_)
) as ffs
on (fs1.fieldid = ffs.f AND fs1.year = year_)) As ft) As ftc;

END
$$;

alter function __geo_get_fieldshape_json(integer, integer) owner to postgres;

