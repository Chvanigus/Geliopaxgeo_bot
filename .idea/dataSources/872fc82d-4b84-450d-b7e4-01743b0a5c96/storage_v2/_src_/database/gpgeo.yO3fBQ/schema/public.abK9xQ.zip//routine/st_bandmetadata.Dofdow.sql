create function st_bandmetadata(rast raster, band integer DEFAULT 1, OUT pixeltype text, OUT nodatavalue double precision, OUT isoutdb boolean, OUT path text) returns record
    immutable
    strict
    language sql
as
$$
SELECT pixeltype, nodatavalue, isoutdb, path FROM st_bandmetadata($1, ARRAY[$2]::int[]) LIMIT 1
$$;

comment on function st_bandmetadata(raster, integer, out text, out double precision, out boolean, out text) is 'args: rast, bandnum=1 - Returns basic meta data for a specific raster band. band num 1 is assumed if none-specified.';

alter function st_bandmetadata(raster, integer, out text, out double precision, out boolean, out text) owner to postgres;

