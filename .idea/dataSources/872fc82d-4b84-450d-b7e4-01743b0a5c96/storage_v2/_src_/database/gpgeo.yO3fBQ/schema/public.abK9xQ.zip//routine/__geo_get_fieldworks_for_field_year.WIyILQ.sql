create function __geo_get_fieldworks_for_field_year(fieldid_ bigint, year_ integer)
    returns TABLE(id bigint, date text, worktype character varying, workgroup character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
select 
	 fw.id
	,to_char(fw.date, 'DD.MM.YYYY') as "date"
	,wt.name as "worktype"
	,wg.name as "workgroup"

from "FieldWork" fw inner join ("WorkType" wt inner join "WorkGroup" wg on wt.workgroupid = wg.id) on fw.worktypeid = wt.id
where EXTRACT(YEAR FROM fw.date)::INTEGER = year_ AND fw.fieldid = fieldid_
order by fw.date DESC;
END;
$$;

alter function __geo_get_fieldworks_for_field_year(bigint, integer) owner to postgres;

