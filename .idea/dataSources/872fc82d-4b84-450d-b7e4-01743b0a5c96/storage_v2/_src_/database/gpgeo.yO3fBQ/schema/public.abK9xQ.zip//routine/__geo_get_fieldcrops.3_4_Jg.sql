create function __geo_get_fieldcrops(agroid_ integer, yieldyear_ integer)
    returns TABLE("FieldCrop_id" bigint, "FieldCrop_fieldid" bigint, "FieldCrop_startdate" text, "FieldCrop_enddate" text, "FieldCrop_yieldplan" real, "FieldCrop_yieldfact" real, "FieldCrop_accountcroparea" real, "FieldCrop_additional" text, "FieldCrop_cropid" integer, "FieldCrop_sortid" integer, "FieldCrop_technologyid" integer, "FieldCrop_generationid" integer, "FieldCrop_densityfact" bigint, "FieldCrop_densityplan" double precision, "FieldCrop_harvestdensity" bigint, germination numeric, "Field_name" character varying, "Crop_name" character varying, "Sort_name" character varying, "Technology_name" character varying, "Generation_name" character varying)
    language plpgsql
as
$$
BEGIN
   RETURN QUERY
   
	select   fc.id as "FieldCrop_id"
			,fc.fieldid as "FieldCrop_fieldid"		
			,to_char(fc.startdate, 'DD.MM.YYYY') as "FieldCrop_startdate"
			,to_char(fc.enddate, 'DD.MM.YYYY') as "FieldCrop_enddate"
			,fc.yieldplan as "FieldCrop_yieldplan"
			,fc.yieldfact as "FieldCrop_yieldfact"		
			,fc.accountcroparea as "FieldCrop_accountcroparea"
			,fc.additional as "FieldCrop_additional"
			,fc.cropid as "FieldCrop_cropid"
			,fc.sortid as "FieldCrop_sortid"
			,fc.technologyid as "FieldCrop_technologyid"
			,fc.generationid as "FieldCrop_generationid"
			
			,fc.densityfact as "FieldCrop_densityfact"
			,fc.densityplan as "FieldCrop_densityplan"
			,fc.harvestdensity as "FieldCrop_harvestdensity"
			,(CASE WHEN fc.densityfact is not null 
						AND fc.densityplan is not null
						AND fc.densityplan <> 0
						THEN round(100*(fc.densityfact/fc.densityplan)::numeric, 2)::numeric
						ELSE null
			 END) as "germination"
		
			,f.name as "Field_name"
			,c.name as "Crop_name"
			,s.name as "Sort_name"
			,t.name as "Technology_name"
			,g.name as "Generation_name"
		
	from 	"FieldCrop" fc 
			inner join "Field" f on (fc.fieldid = f.id AND f.agroid = agroid_ AND fc.yieldyear = yieldyear_)
			inner join "Crop" c on fc.cropid = c.id
			left outer join "Sort" s on fc.sortid = s.id
			left outer join "Technology" t on fc.technologyid = t.id
			left outer join "Generation" g on fc.generationid = g.id
		
	order by cast(NULLIF(regexp_replace(f.name, E'\\D', '', 'g'), '') AS integer), fc.cropid, fc.sortid, fc.technologyid;

END;
$$;

alter function __geo_get_fieldcrops(integer, integer) owner to postgres;

