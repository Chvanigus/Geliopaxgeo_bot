create function __geoutil__get_fieldcrop_json(agroid_ integer, year_ integer, fieldgroupid_ integer) returns json
    language plpgsql
as
$$ 
  
BEGIN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
	    , ga.geometry
		, row_to_json(row(f.name, ga.area_calc, prop.sum_crop_area, prop."FieldGroup", ga."centrX", ga."centrY", f.name || '|' || prop.sum_crop_area, array_to_string(technologies, ''), array_to_string(cropids, '|'), colors[1], prop.crop)::"__geoUtil_fieldCropJsonProp") as properties

from
"Field" f 

inner join (

(select  geom.field_id
		, geom.fieldcrop_id
		, ST_AsGeoJSON(geom.geometry)::json As geometry
		, round (cast (ST_Area(ST_Transform(geom.geometry, 32638)) / 10000 as numeric), 2) As "area_calc"
		, ST_X (ST_Centroid(geom.geometry)) As "centrX"
		, ST_Y (ST_Centroid(geom.geometry)) As "centrY"
from
(select	  shape.fieldid as field_id		
		, (CASE WHEN plotgeometry is not null THEN plotgeometry 
											  ELSE fieldgeometry
		  END) as geometry
		, (CASE WHEN plotgeometry is not null THEN fieldcropid 
											  ELSE 0
		  END) as fieldcrop_id
From
		(Select   f.id as fieldid
				, fc.id as fieldcropid
			    , fp.plotgeometry as plotgeometry
				, fs.fieldgeometry as fieldgeometry
		From
			"FieldCrop" As fc
			inner join ("Field" As f inner join "FieldShape" As fs on (f.id = fs.fieldid AND fs.year = year_))
			on (fc.fieldid = f.id AND f.agroid = agroid_ AND fc.yieldyear = year_)		
			left outer join "FieldPlot" As fp on (fp.id = fc.fieldplotid)) As shape
group by geometry, field_id, fieldcrop_id) as geom) as ga

inner join 

(select   f1_.fid as field_id		
		, f2.fieldcropid As fieldcrop_id
		, f2."FieldGroup" As "FieldGroup"
		, sum(f2."AccountCropArea") As sum_crop_area
		, array_to_json(array_agg(f2.properties1)) As crop
		, array_agg(DISTINCT f2.cropid) as cropids
		, array_agg(DISTINCT f2.technology) as technologies	
		, array_agg(DISTINCT f2.color) as colors	
from 	(select   f1.id as fid				
				, f1.agroid as agroid
				, fc1.id as fcid
		from
			"Field" as f1 
			left outer join "FieldCrop" as fc1 on (f1.id = fc1.fieldid AND fc1.fieldplotid is not null AND f1.agroid = agroid_ AND fc1.yieldyear = year_)
		) As f1_	
		
		inner join	
		
			(select   ffc.f as fid
					, ffc As properties1
					, ffc.c As cropid
					, ffc."Technology" As technology
					, ffc."Color" As color
					, ffc."AccountCropArea" As "AccountCropArea"
					, ffc."FieldGroup" As "FieldGroup"
					, (CASE WHEN ffc.fp is not null THEN ffc.fc 
													ELSE 0
					   END) as fieldcropid					
			from 
					(select   fc_.id	as "fc"						
							, fc_.fieldid  as "f"
							, fc_.fieldplotid  as "fp"							
							, fc_.accountcroparea as "AccountCropArea"
							
							, c.id as "c"
							, c.name as "Name"
							, '#' || c.color as "Color"
							
							, t.shortname as "Technology"
							
							, s.shortname as "Sort"	

							,ffg.fieldgroupid as "FieldGroup"
					from "Field" as f_ inner join 
						 ("FieldCrop" as fc_ 
							inner join "Crop" as c on c.id = fc_.cropid
							left outer join "Technology" as t on t.id = fc_.technologyid
							left outer join "Sort" as s on s.id = fc_.sortid)  
						on (fc_.fieldid = f_.id  AND f_.agroid = agroid_ AND fc_.yieldyear = year_)
						inner join "FieldFieldGroup" as ffg on(f_.id = ffg.fieldid AND ffg.year = year_ AND ffg.fieldgroupid=fieldgroupid_)					
					) as ffc
			) as f2 
		on (f1_.fid = f2.fid AND f1_.agroid = agroid_ AND (f1_.fcid = f2.fieldcropid OR (f1_.fcid is null AND f2.fieldcropid = 0)))
group by f1_.fid, f2.fieldcropid, f2."FieldGroup") as prop
on (ga.field_id = prop.field_id AND ga.fieldcrop_id = prop.fieldcrop_id)) on f.id = ga.field_id) As ft) As ftc;

END
$$;

alter function __geoutil__get_fieldcrop_json(integer, integer, integer) owner to geoadmin;

