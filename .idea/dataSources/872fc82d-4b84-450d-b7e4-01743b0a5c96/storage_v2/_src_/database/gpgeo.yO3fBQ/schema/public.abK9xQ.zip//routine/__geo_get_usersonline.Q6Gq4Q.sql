create function __geo_get_usersonline()
    returns TABLE(id bigint, login character varying, firstname character varying, secondname character varying, surname character varying, role character varying, last_activity text, last_ip character varying, agros integer[])
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
select 

u.id,
u.login,
u.firstname,
u.secondname,
u.surname,
r.name as "role",
to_char(s.last_activity, 'DD.MM.YYYY HH24:MI:SS') as "last_activity",
s.last_ip,
au.agros

from
"session" s inner join ("User" u inner join "Role" r on u.role = r.id
								 left outer join 
									(select  userid
											,array_agg(agroid) as agros
									 from "AgroUser"
									 group by userid 
									)au on u.id = au.userid
						) on s.user_id = u.id;
END;
$$;

alter function __geo_get_usersonline() owner to postgres;

