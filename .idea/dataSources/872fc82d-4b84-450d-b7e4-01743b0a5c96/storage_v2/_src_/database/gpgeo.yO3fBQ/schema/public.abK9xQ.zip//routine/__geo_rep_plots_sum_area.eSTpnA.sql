create function __geo_rep_plots_sum_area(year_ bigint, fieldid_ bigint)
    returns TABLE(areasum real)
    language plpgsql
as
$$
BEGIN
   RETURN QUERY
   
	--select   fc.id as "FieldCrop_id"	
	--		,fc.accountcroparea as "FieldCrop_accountcroparea"
	--		,fc.yieldfact as "FieldCrop_yieldfact"
	--		,fc.cropid as "FieldCrop_cropid"
			
	--from 	"FieldCrop" fc 
	
	--where 	fc.fieldid = fieldid_ AND fc.yieldyear = (year_ - 1);

select tmp.areasum_ as areasum from 

	(SELECT  
"FieldCrop".fieldid as field_id,
SUM("FieldCrop".accountcroparea) as areasum_


FROM

public."FieldCrop",
public."Crop"

WHERE

"FieldCrop".fieldid = fieldid_ AND
"FieldCrop".yieldyear = (year_ + 0) AND
"FieldCrop".cropid = "Crop".id

GROUP BY "FieldCrop".fieldid ) as tmp;	
END;
$$;

alter function __geo_rep_plots_sum_area(bigint, bigint) owner to geoadmin;

