create function st_linefromwkb(bytea, integer) returns geometry
    immutable
    strict
    language sql
as
$$
	SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END
	$$;

comment on function st_linefromwkb(bytea, integer) is 'args: WKB, srid - Makes a LINESTRING from WKB with the given SRID';

alter function st_linefromwkb(bytea, integer) owner to postgres;

