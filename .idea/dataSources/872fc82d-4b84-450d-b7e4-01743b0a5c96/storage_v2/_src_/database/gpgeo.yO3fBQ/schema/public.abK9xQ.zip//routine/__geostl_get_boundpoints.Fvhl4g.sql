create function __geostl_get_boundpoints(year_ integer, proj_ integer, fieldid_ integer, agroid_ integer)
    returns TABLE(lat double precision, lon double precision)
    language plpgsql
as
$$

BEGIN

	IF fieldid_ IS NOT NULL THEN
		RETURN QUERY 
		SELECT ST_X(s.point), ST_Y(s.point)
		FROM
			  ( SELECT (ST_DumpPoints(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))).geom as point 
			FROM "FieldShape" fs
			WHERE fs.year = year_  AND fs.fieldid = fieldid_ ) s;

	ELSIF agroid_ IS NULL THEN
		RETURN QUERY 
		SELECT ST_X(s.point), ST_Y(s.point)
		from
		( SELECT (ST_DumpPoints(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))).geom as point 
			FROM "FieldShape" fs
			where fs.year = year_ ) s;
			
	ELSE
		RETURN QUERY 
		SELECT ST_X(s.point), ST_Y(s.point)
		from
		( SELECT (ST_DumpPoints(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))).geom as point 
			FROM "FieldShape" fs inner join "Field" f on (f.id = fs.fieldid 
								      AND fs.year = year_
								      AND f.agroid = agroid_) ) s;
	END IF;	
END;

$$;

alter function __geostl_get_boundpoints(integer, integer, integer, integer) owner to geoadmin;

