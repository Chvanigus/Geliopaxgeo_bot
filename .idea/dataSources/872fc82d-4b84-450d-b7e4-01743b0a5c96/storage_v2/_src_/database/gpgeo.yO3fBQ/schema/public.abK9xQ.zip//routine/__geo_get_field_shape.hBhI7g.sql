create function __geo_get_field_shape(fieldid_ integer, year_ integer) returns json
    language plpgsql
as
$$   
BEGIN
   return 
			(CASE WHEN geometry is not null THEN row_to_json(ftc) 
											ELSE null
			END)
FROM (SELECT 'Feature' As type
		    , ST_AsGeoJSON(fs.fieldgeometry)::json As geometry				
		
	  FROM "FieldShape" as fs
	  Where fs.fieldid = fieldid_ AND fs.year = year_) As ftc;

END
$$;

alter function __geo_get_field_shape(integer, integer) owner to postgres;

