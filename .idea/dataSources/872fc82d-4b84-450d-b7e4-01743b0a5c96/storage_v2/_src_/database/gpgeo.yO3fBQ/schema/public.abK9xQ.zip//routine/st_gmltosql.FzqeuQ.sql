create function st_gmltosql(text) returns geometry
    immutable
    strict
    language sql
as
$$SELECT _ST_GeomFromGML($1, 0)$$;

comment on function st_gmltosql(text) is 'args: geomgml - Return a specified ST_Geometry value from GML representation. This is an alias name for ST_GeomFromGML';

alter function st_gmltosql(text) owner to postgres;

