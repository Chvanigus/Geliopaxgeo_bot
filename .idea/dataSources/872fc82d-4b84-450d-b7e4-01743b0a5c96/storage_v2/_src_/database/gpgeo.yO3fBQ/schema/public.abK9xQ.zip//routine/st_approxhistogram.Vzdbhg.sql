create function st_approxhistogram(rast raster, sample_percent double precision, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, 1, TRUE, $2, 0, NULL, FALSE)
$$;

alter function st_approxhistogram(raster, double precision, out double precision, out double precision, out bigint, out double precision) owner to postgres;

